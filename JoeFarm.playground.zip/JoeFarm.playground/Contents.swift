//: Playground - noun: a place where people can play

import UIKit
var taille = ["Papa":1.78,"Céleste":1.73,"Iris":1.64,"Ambroise":1.81,"Maman":1.71]

var somme = 0.0
var moyenne: Double
for (nini,tail) in taille {
somme+=tail
    print("\(nini)")
}
print("La taille totale est de \(somme)) !")
readline()
input()

